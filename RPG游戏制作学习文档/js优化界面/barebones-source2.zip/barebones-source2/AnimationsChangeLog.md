# animations.lua ChangeLog

### Version 0.83
- Fixed an issue where perfectly sequential animations would not play
- Added several missing translate activity modifiers
- Added AddAnimationTranslate and RemoveAnimationTranslate commands to allow for easily adding/removing permanent translates like "injured"/"haste", etc

### Version 0.80
- Added animations.lua library
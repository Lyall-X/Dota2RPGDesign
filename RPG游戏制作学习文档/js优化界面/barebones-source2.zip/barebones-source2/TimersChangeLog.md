# timers.lua ChangeLog

### Version 1.01
- Added additional guards to better handle 'script_reload' 

### Version 1.00
- Added global TIMERS_VERSION
- Started tracking version updates for timers.lua
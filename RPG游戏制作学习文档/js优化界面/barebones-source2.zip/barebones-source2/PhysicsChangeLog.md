# physics.lua ChangeLog

### Version 0.91
- Added additional guards to better handle 'script_reload' 

### Version 0.90
- Added global PHYSICS_VERSION
- Started tracking version updates for physics.lua
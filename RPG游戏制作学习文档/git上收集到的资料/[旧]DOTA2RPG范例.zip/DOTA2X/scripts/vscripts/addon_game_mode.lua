-- 这里我们只写一个内容，DOTA2XGameMode:初始化
DOTA2XGameMode:InitGameMode()
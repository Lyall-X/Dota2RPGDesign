-- Tell the user it is loading
print('\n\nLegends of Dota modules are loading...')

-- Load modules
require('skillmanager')
require('easytimers')

-- Tell the user it has loaded
print('Legends of Dota modules have finished loading!\n\n')

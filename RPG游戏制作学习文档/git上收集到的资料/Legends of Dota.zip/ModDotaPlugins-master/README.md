ModDota Plugins
=====

###About###
 - Each folder contains a unique addon / plugin / mod for Dota 2.

###Custom Spell Power###
 - This is a plugin which changes the spell values
 - This plugin currently gives random abilities and hero stats
 - Currently, you'll need the console to access this gamemode, add `-console` to the launch parameters of dota 2, in the meta game section of the options, you can select a bind for it, the default is either `\` or `~` depending on your setup
 - `dota_local_addon_enable 1;dota_local_addon_game csp;dota_local_addon_map dota;dota_force_gamemode 1;update_addon_paths;map dota;`
 - To join a team, type either `jointeam good` or `jointeam bad`
 - Once you're at the hero selection screen, you can optionally choose to fill the rest of the slots with bots by typing `dota_bot_populate`

###Legends of Dota###
 - `dota_local_addon_enable 1;dota_local_addon_game lod;dota_force_gamemode 15;update_addon_paths;map dota_lod;`

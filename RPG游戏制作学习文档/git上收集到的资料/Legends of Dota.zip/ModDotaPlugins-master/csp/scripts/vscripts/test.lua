
--PrecacheResource("particlefile","particles/units/heroes/hero_queenofpain.pcf", nil)

--local a = CreateUnitByName("npc_dota_hero_queenofpain",RandomVector(1), false, nil, nil, DOTA_TEAM_GOODGUYS)
--print(a)
--a:Remove()

--local a = CreateHeroForPlayer("npc_dota_hero_queenofpain", PlayerResource:GetPlayer(0))
--a:Remove()
--print(a)

PrintTable(_G)

over=false
function ability_1_run(caster,face_go,face_back,casterVec,targetVec)
	local overVec = targetVec + 500*face_go

	GameRules:GetGameModeEntity():SetContextThink(DoUniqueString("ability_1_run_time_1"), 
		function( )
			local casterVec_2 = caster:GetOrigin() 
			if (casterVec_2 - overVec):Length()>50 then
				local casterAbs = caster:GetAbsOrigin()
				local face = (overVec - casterAbs):Normalized()
				local vec = face*100.0
				caster:SetAbsOrigin(casterAbs + vec)
				return 0.01
			else
				caster:SetForwardVector(face_back)
				GameRules:GetGameModeEntity():SetContextThink(DoUniqueString("ability_1_run_time_2"), 
					function( )
						local casterVec_2 = caster:GetOrigin() 
						if (casterVec_2 - casterVec):Length()>50 then
							local casterAbs = caster:GetAbsOrigin()
							local face = (casterVec - casterAbs):Normalized()
							local vec = face*100.0
							caster:SetAbsOrigin(casterAbs + vec)
							return 0.01
						else
							over=true
							caster:RemoveAbility("myability_1_dummy")
							caster:RemoveModifierByName("modifier_myability_1_dummy")
							caster:RemoveModifierByName("modifier_phased")
							return nil
						end
					end, 0.05)
				
				return nil
			end
		end, 0)
end

function ability_1_removeunit(unit , time)
	GameRules:GetGameModeEntity():SetContextThink(DoUniqueString("ability_1_removeunit_time"), 
		function( )
			unit:RemoveSelf()
		end, time)
end

function ability_1( keys )
	local caster = keys.caster
	local target = keys.target
	local casterName = caster:GetUnitName()
	local casterVec = caster:GetOrigin()
	local targetVec = target:GetOrigin()
	local face_go = (targetVec - casterVec):Normalized()
	local face_back = (casterVec - targetVec):Normalized()
	local overVec = targetVec + 500*face_go
	caster:SetForwardVector(face_go)
	caster:AddNewModifier(caster, keys.ability, "modifier_phased", caster)

	local abilityName = "myability_1_dummy"
	caster:AddAbility(abilityName) 
	local ability =caster:FindAbilityByName(abilityName)
	ability:SetLevel(1) 
	ability_1_run(caster,face_go,face_back,casterVec,targetVec)
	over=false
	GameRules:GetGameModeEntity():SetContextThink(DoUniqueString("ability_1_time_1"), 
		function( )
			if over==false then
				local unit = CreateUnitByName(casterName, caster:GetOrigin(), false, nil, nil, caster:GetTeam())
				unit:SetForwardVector(caster:GetForwardVector())
				unit:AddAbility(abilityName)
				ability_1_removeunit(unit,0.3)
				local ability =unit:FindAbilityByName(abilityName)
				ability:SetLevel(1) 
				return 0.02
			else
				return nil
			end
		end, 0)
	
end